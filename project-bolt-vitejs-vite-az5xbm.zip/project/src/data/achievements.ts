import { icons } from '../utils/achievementIcons';

export interface Achievement {
  id: string;
  icon: () => JSX.Element;
  title: string;
  description: string;
  condition: boolean;
  rarity: 'common' | 'rare' | 'epic' | 'legendary';
  unlockedAt?: Date;
}

// Helper function to create achievement groups
const createSpeedAchievements = (wpm: number): Achievement[] => [
  {
    id: 'speed-20',
    icon: icons.zap,
    title: "Acemi Yazıcı",
    description: "20+ WPM hızına ulaştın!",
    condition: wpm >= 20,
    rarity: 'common'
  },
  {
    id: 'speed-30',
    icon: icons.zap,
    title: "Hız Çırağı",
    description: "30+ WPM hızına ulaştın!",
    condition: wpm >= 30,
    rarity: 'common'
  },
  {
    id: 'speed-40',
    icon: icons.zap,
    title: "Hızlı Parmaklar",
    description: "40+ WPM hızına ulaştın!",
    condition: wpm >= 40,
    rarity: 'common'
  },
  {
    id: 'speed-50',
    icon: icons.fastZap,
    title: "Hız Ustası",
    description: "50+ WPM hızına ulaştın!",
    condition: wpm >= 50,
    rarity: 'rare'
  },
  {
    id: 'speed-60',
    icon: icons.fastZap,
    title: "Klavye Virtüözü",
    description: "60+ WPM hızına ulaştın!",
    condition: wpm >= 60,
    rarity: 'rare'
  },
  {
    id: 'speed-70',
    icon: icons.fastZap,
    title: "Hız Avcısı",
    description: "70+ WPM hızına ulaştın!",
    condition: wpm >= 70,
    rarity: 'rare'
  },
  {
    id: 'speed-80',
    icon: icons.rocket,
    title: "Hız Efsanesi",
    description: "80+ WPM hızına ulaştın!",
    condition: wpm >= 80,
    rarity: 'epic'
  },
  {
    id: 'speed-90',
    icon: icons.rocket,
    title: "Süper Hız",
    description: "90+ WPM hızına ulaştın!",
    condition: wpm >= 90,
    rarity: 'epic'
  },
  {
    id: 'speed-100',
    icon: icons.trophy,
    title: "Hız Şampiyonu",
    description: "100+ WPM hızına ulaştın!",
    condition: wpm >= 100,
    rarity: 'legendary'
  },
  {
    id: 'speed-120',
    icon: icons.trophy,
    title: "Klavye Büyücüsü",
    description: "120+ WPM hızına ulaştın!",
    condition: wpm >= 120,
    rarity: 'legendary'
  }
];

const createAccuracyAchievements = (accuracy: number): Achievement[] => [
  {
    id: 'accuracy-70',
    icon: icons.target,
    title: "Dikkatli Yazıcı",
    description: "70%+ doğruluk oranı!",
    condition: accuracy >= 70,
    rarity: 'common'
  },
  {
    id: 'accuracy-80',
    icon: icons.target,
    title: "Özenli Yazıcı",
    description: "80%+ doğruluk oranı!",
    condition: accuracy >= 80,
    rarity: 'common'
  },
  {
    id: 'accuracy-90',
    icon: icons.shield,
    title: "Keskin Nişancı",
    description: "90%+ doğruluk oranı!",
    condition: accuracy >= 90,
    rarity: 'rare'
  },
  {
    id: 'accuracy-95',
    icon: icons.shield,
    title: "Hassas Atış",
    description: "95%+ doğruluk oranı!",
    condition: accuracy >= 95,
    rarity: 'epic'
  },
  {
    id: 'accuracy-98',
    icon: icons.shield,
    title: "Kusursuzluğa Yakın",
    description: "98%+ doğruluk oranı!",
    condition: accuracy >= 98,
    rarity: 'legendary'
  },
  {
    id: 'accuracy-100',
    icon: icons.award,
    title: "Mükemmeliyetçi",
    description: "100% doğruluk!",
    condition: accuracy === 100,
    rarity: 'legendary'
  }
];

const createStreakAchievements = (streak: number): Achievement[] => [
  {
    id: 'streak-5',
    icon: icons.flame,
    title: "Seri Başlangıç",
    description: "5+ kelime hatasız!",
    condition: streak >= 5,
    rarity: 'common'
  },
  {
    id: 'streak-10',
    icon: icons.flame,
    title: "Ateş Serisi",
    description: "10+ kelime hatasız!",
    condition: streak >= 10,
    rarity: 'rare'
  },
  {
    id: 'streak-15',
    icon: icons.flame,
    title: "Alev Zinciri",
    description: "15+ kelime hatasız!",
    condition: streak >= 15,
    rarity: 'rare'
  },
  {
    id: 'streak-20',
    icon: icons.crown,
    title: "Seri Uzmanı",
    description: "20+ kelime hatasız!",
    condition: streak >= 20,
    rarity: 'epic'
  },
  {
    id: 'streak-25',
    icon: icons.crown,
    title: "Seri Kralı",
    description: "25+ kelime hatasız!",
    condition: streak >= 25,
    rarity: 'epic'
  },
  {
    id: 'streak-30',
    icon: icons.crown,
    title: "Seri İmparatoru",
    description: "30+ kelime hatasız!",
    condition: streak >= 30,
    rarity: 'legendary'
  }
];

const createCombinationAchievements = (wpm: number, accuracy: number, streak: number): Achievement[] => [
  {
    id: 'beginner-combo',
    icon: icons.medal,
    title: "Başlangıç Ustalığı",
    description: "30+ WPM ve 80%+ doğruluk!",
    condition: wpm >= 30 && accuracy >= 80,
    rarity: 'common'
  },
  {
    id: 'intermediate-combo',
    icon: icons.medal,
    title: "Orta Seviye Ustalık",
    description: "50+ WPM ve 90%+ doğruluk!",
    condition: wpm >= 50 && accuracy >= 90,
    rarity: 'rare'
  },
  {
    id: 'advanced-combo',
    icon: icons.star,
    title: "İleri Seviye Ustalık",
    description: "70+ WPM ve 95%+ doğruluk!",
    condition: wpm >= 70 && accuracy >= 95,
    rarity: 'epic'
  },
  {
    id: 'expert-combo',
    icon: icons.star,
    title: "Uzman Seviye",
    description: "90+ WPM ve 98%+ doğruluk!",
    condition: wpm >= 90 && accuracy >= 98,
    rarity: 'legendary'
  },
  {
    id: 'perfect-combo',
    icon: icons.trophy,
    title: "Mükemmel Performans",
    description: "100+ WPM ve 100% doğruluk!",
    condition: wpm >= 100 && accuracy === 100,
    rarity: 'legendary'
  },
  {
    id: 'streak-master',
    icon: icons.brain,
    title: "Seri Ustası",
    description: "70+ WPM ve 20+ kelime serisi!",
    condition: wpm >= 70 && streak >= 20,
    rarity: 'epic'
  },
  {
    id: 'ultimate-master',
    icon: icons.crown,
    title: "Nihai Ustalık",
    description: "100+ WPM, 98%+ doğruluk ve 25+ seri!",
    condition: wpm >= 100 && accuracy >= 98 && streak >= 25,
    rarity: 'legendary'
  }
];

const createProgressAchievements = (testCount: number): Achievement[] => [
  {
    id: 'first-test',
    icon: icons.book,
    title: "İlk Adım",
    description: "İlk testini tamamladın!",
    condition: testCount >= 1,
    rarity: 'common'
  },
  {
    id: 'dedicated-5',
    icon: icons.book,
    title: "Özenli Öğrenci",
    description: "5 test tamamladın!",
    condition: testCount >= 5,
    rarity: 'common'
  },
  {
    id: 'dedicated-10',
    icon: icons.coffee,
    title: "Düzenli Pratik",
    description: "10 test tamamladın!",
    condition: testCount >= 10,
    rarity: 'rare'
  },
  {
    id: 'dedicated-25',
    icon: icons.coffee,
    title: "Kararlı Öğrenci",
    description: "25 test tamamladın!",
    condition: testCount >= 25,
    rarity: 'rare'
  },
  {
    id: 'dedicated-50',
    icon: icons.timer,
    title: "Azimli Yazıcı",
    description: "50 test tamamladın!",
    condition: testCount >= 50,
    rarity: 'epic'
  },
  {
    id: 'dedicated-100',
    icon: icons.heart,
    title: "Tutkulu Yazıcı",
    description: "100 test tamamladın!",
    condition: testCount >= 100,
    rarity: 'legendary'
  }
];

export const allAchievements = (
  wpm: number, 
  accuracy: number, 
  streak: number, 
  testCount: number = 0
): Achievement[] => [
  ...createSpeedAchievements(wpm),
  ...createAccuracyAchievements(accuracy),
  ...createStreakAchievements(streak),
  ...createCombinationAchievements(wpm, accuracy, streak),
  ...createProgressAchievements(testCount)
];