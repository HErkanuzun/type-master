import React, { useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Achievement } from '../data/achievements';

interface AchievementsProps {
  wpm: number;
  accuracy: number;
  streak: number;
  showDrawer: boolean;
  onCloseDrawer: () => void;
  unlockedAchievements: Achievement[];
}

const rarityColors = {
  common: 'from-gray-400 to-gray-300',
  rare: 'from-blue-400 to-blue-300',
  epic: 'from-purple-400 to-purple-300',
  legendary: 'from-yellow-400 to-yellow-300'
};

export default function Achievements({ 
  wpm, 
  accuracy, 
  streak, 
  showDrawer, 
  onCloseDrawer,
  unlockedAchievements 
}: AchievementsProps) {
  const drawerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (drawerRef.current && !drawerRef.current.contains(event.target as Node)) {
        onCloseDrawer();
      }
    };

    if (showDrawer) {
      document.addEventListener('mousedown', handleClickOutside);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [showDrawer, onCloseDrawer]);

  const recentUnlocks = unlockedAchievements.filter(a => 
    a.unlockedAt && new Date().getTime() - a.unlockedAt.getTime() < 5000
  );

  if (showDrawer) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50"
      >
        <motion.div
          ref={drawerRef}
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          className="glass-card rounded-2xl p-8 max-w-2xl w-full"
        >
          <h2 className="text-2xl font-bold text-white mb-6">Başarılar</h2>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 overflow-y-auto max-h-[60vh] pr-2 custom-scrollbar">
            {unlockedAchievements.map((achievement) => (
              <div
                key={achievement.id}
                className={`p-4 rounded-xl glass bg-gradient-to-r ${rarityColors[achievement.rarity]} bg-opacity-20`}
              >
                <div className="flex items-center gap-3">
                  {achievement.icon()}
                  <div>
                    <h3 className="font-semibold text-white">{achievement.title}</h3>
                    <p className="text-sm text-white/70">{achievement.description}</p>
                    <span className="text-xs text-white/50 capitalize">{achievement.rarity}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      </motion.div>
    );
  }

  return (
    <AnimatePresence>
      {recentUnlocks.map((achievement) => (
        <motion.div
          key={achievement.id}
          initial={{ opacity: 0, x: 50 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -50 }}
          className={`fixed bottom-4 right-4 p-4 rounded-xl glass bg-gradient-to-r ${
            rarityColors[achievement.rarity]
          } bg-opacity-20 z-50`}
        >
          <div className="flex items-center gap-3 text-white">
            {achievement.icon()}
            <div>
              <h3 className="font-semibold">{achievement.title}</h3>
              <p className="text-sm opacity-90">{achievement.description}</p>
            </div>
          </div>
        </motion.div>
      ))}
    </AnimatePresence>
  );
}