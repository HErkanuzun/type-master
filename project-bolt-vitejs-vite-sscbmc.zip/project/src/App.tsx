import React from 'react';
import TypingTest from './components/TypingTest';
import SEO from './components/SEO';

function App() {
  return (
    <>
      <SEO />
      <TypingTest />
    </>
  );
}

export default App;