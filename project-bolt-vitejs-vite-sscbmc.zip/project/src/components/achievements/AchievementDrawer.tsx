import React, { useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Achievement } from '../../types/achievements';
import AchievementCard from './AchievementCard';
import AchievementStats from './AchievementStats';

interface AchievementDrawerProps {
  unlockedAchievements: Achievement[];
  onClose: () => void;
}

export default function AchievementDrawer({ unlockedAchievements, onClose }: AchievementDrawerProps) {
  const drawerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (drawerRef.current && !drawerRef.current.contains(event.target as Node)) {
        onClose();
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [onClose]);

  const totalAchievements = 40; // Toplam başarı sayısı
  const progress = (unlockedAchievements.length / totalAchievements) * 100;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50"
    >
      <motion.div
        ref={drawerRef}
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="glass-card rounded-2xl p-8 max-w-2xl w-full"
      >
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-white">Başarılar</h2>
          <AchievementStats
            total={totalAchievements}
            unlocked={unlockedAchievements.length}
            progress={progress}
          />
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 overflow-y-auto max-h-[60vh] pr-2 custom-scrollbar">
          {unlockedAchievements.map((achievement) => (
            <AchievementCard
              key={achievement.id}
              achievement={achievement}
            />
          ))}
        </div>
      </motion.div>
    </motion.div>
  );
}