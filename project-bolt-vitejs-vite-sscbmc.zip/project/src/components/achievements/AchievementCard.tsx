import React from 'react';
import { Achievement } from '../../types/achievements';

interface AchievementCardProps {
  achievement: Achievement;
}

const rarityColors = {
  common: 'from-gray-400 to-gray-300',
  rare: 'from-blue-400 to-blue-300',
  epic: 'from-purple-400 to-purple-300',
  legendary: 'from-yellow-400 to-yellow-300'
};

export default function AchievementCard({ achievement }: AchievementCardProps) {
  return (
    <div className={`p-4 rounded-xl glass bg-gradient-to-r ${rarityColors[achievement.rarity]} bg-opacity-20`}>
      <div className="flex items-center gap-3">
        {achievement.icon()}
        <div>
          <h3 className="font-semibold text-white">{achievement.title}</h3>
          <p className="text-sm text-white/70">{achievement.description}</p>
          <span className="text-xs text-white/50 capitalize">{achievement.rarity}</span>
        </div>
      </div>
    </div>
  );
}