import React from 'react';

interface WordDisplayProps {
  currentWord: string;
  typedText: string;
  nextWords: string[];
}

export default function WordDisplay({ currentWord, typedText, nextWords }: WordDisplayProps) {
  return (
    <div className="font-mono text-base sm:text-lg mb-4 leading-relaxed overflow-x-auto whitespace-nowrap custom-scrollbar pb-2">
      <span className="mr-2">
        {currentWord.split('').map((char, index) => {
          const typedChar = typedText[index];
          let className = 'text-white/50'; // Default state

          if (typedChar !== undefined) {
            className = typedChar === char ? 'text-blue-400' : 'text-red-400';
          }

          return (
            <span key={index} className={className}>
              {char}
            </span>
          );
        })}
      </span>
      <span className="text-white/30">
        {nextWords.join(' ')}
      </span>
    </div>
  );
}