export const words = {
  tr: [
    'merhaba', 'dünya', 'klavye', 'bilgisayar', 'yazılım', 'teknoloji', 'internet',
    'program', 'öğrenmek', 'çalışmak', 'kitap', 'okul', 'öğrenci', 'öğretmen',
    'masa', 'kalem', 'defter', 'telefon', 'ekran', 'fare', 'pencere', 'kapı',
    'güneş', 'ay', 'yıldız', 'deniz', 'gökyüzü', 'ağaç', 'çiçek', 'kuş'
  ],
  en: [
    'hello', 'world', 'keyboard', 'computer', 'software', 'technology', 'internet',
    'program', 'learning', 'working', 'book', 'school', 'student', 'teacher',
    'desk', 'pencil', 'notebook', 'phone', 'screen', 'mouse', 'window', 'door',
    'sun', 'moon', 'star', 'sea', 'sky', 'tree', 'flower', 'bird'
  ]
};